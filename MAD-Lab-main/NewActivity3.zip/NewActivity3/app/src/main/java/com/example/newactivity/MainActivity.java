package com.example.newactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    EditText username1,passw;
    Button loginbutton;
    String name="Admin";
    String password="admin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username1=findViewById(R.id.username);
        passw=findViewById(R.id.pass);
        loginbutton=findViewById(R.id.loginbutton);

        loginbutton.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View view) {
                                               String inpName = username1.getText().toString();
                                               String inpps = passw.getText().toString();
                                               if (inpName.isEmpty() || inpps.isEmpty()) {
                                                   Toast.makeText(MainActivity.this, "fields are empty", Toast.LENGTH_SHORT).show();
                                               } else {
                                                   if (inpName.equals(name) && inpps.equals(password)) {
                                                       Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                                   }
                                                   else{
                                                        Toast.makeText(MainActivity.this, "Incorrect Username or Password ", Toast.LENGTH_SHORT).show();
                                                   }

                                                }
                                         }
    });
}
}


